﻿Imports RegOps.ShowColourPicker.ShowColourPicker

Public Class Main
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim Info As String
        Info = RegOps.SelectionDialog.SelectDialog.OpenDialog(5, "L:\TL_GIS\DATA\BASE_DATA\STIMS\STIMSStudentRoutes.txt", "Select routes")
        'Info =
        MsgBox("Info is " & Info)
    End Sub

    Private Sub butChangeColour_Click(sender As Object, e As EventArgs) Handles butChangeColour.Click
        Dim Response As Integer

        Response = GetRGBColour()
        MsgBox("Response is " & Response)
    End Sub

    Private Sub butShowConfirmationDialog_Click(sender As Object, e As EventArgs) Handles butShowConfirmationDialog.Click
        Dim Response As Integer = ConditionsDialog.ShowConditionsForm.ShowConditionsDialog()

        MsgBox("Response is " & Response)
    End Sub

    Private Sub butHelloMessage_Click(sender As Object, e As EventArgs) Handles butHelloMessage.Click
        Call HelloWorld.HelloWorld.SayHello("Testing")
    End Sub

    Private Sub butSelectInfo_Click(sender As Object, e As EventArgs) Handles butSelectInfo.Click

    End Sub
End Class