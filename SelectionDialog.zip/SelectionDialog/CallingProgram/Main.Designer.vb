﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.butChangeColour = New System.Windows.Forms.Button()
        Me.butSelectInfo = New System.Windows.Forms.Button()
        Me.butShowConfirmationDialog = New System.Windows.Forms.Button()
        Me.butHelloMessage = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(304, 20)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(120, 32)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Select Routes"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'butChangeColour
        '
        Me.butChangeColour.Location = New System.Drawing.Point(304, 132)
        Me.butChangeColour.Name = "butChangeColour"
        Me.butChangeColour.Size = New System.Drawing.Size(113, 23)
        Me.butChangeColour.TabIndex = 1
        Me.butChangeColour.Text = "Change Colour"
        Me.butChangeColour.UseVisualStyleBackColor = True
        '
        'butSelectInfo
        '
        Me.butSelectInfo.Location = New System.Drawing.Point(304, 80)
        Me.butSelectInfo.Name = "butSelectInfo"
        Me.butSelectInfo.Size = New System.Drawing.Size(113, 23)
        Me.butSelectInfo.TabIndex = 2
        Me.butSelectInfo.Text = "Select Info"
        Me.butSelectInfo.UseVisualStyleBackColor = True
        '
        'butShowConfirmationDialog
        '
        Me.butShowConfirmationDialog.Location = New System.Drawing.Point(304, 250)
        Me.butShowConfirmationDialog.Name = "butShowConfirmationDialog"
        Me.butShowConfirmationDialog.Size = New System.Drawing.Size(113, 23)
        Me.butShowConfirmationDialog.TabIndex = 3
        Me.butShowConfirmationDialog.Text = "Show Message"
        Me.butShowConfirmationDialog.UseVisualStyleBackColor = True
        '
        'butHelloMessage
        '
        Me.butHelloMessage.Location = New System.Drawing.Point(304, 193)
        Me.butHelloMessage.Name = "butHelloMessage"
        Me.butHelloMessage.Size = New System.Drawing.Size(113, 23)
        Me.butHelloMessage.TabIndex = 4
        Me.butHelloMessage.Text = "Hello Message"
        Me.butHelloMessage.UseVisualStyleBackColor = True
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.butHelloMessage)
        Me.Controls.Add(Me.butShowConfirmationDialog)
        Me.Controls.Add(Me.butSelectInfo)
        Me.Controls.Add(Me.butChangeColour)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Main"
        Me.Text = "Main"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents butChangeColour As Button
    Friend WithEvents butSelectInfo As Button
    Friend WithEvents butShowConfirmationDialog As Button
    Friend WithEvents butHelloMessage As Button
End Class
