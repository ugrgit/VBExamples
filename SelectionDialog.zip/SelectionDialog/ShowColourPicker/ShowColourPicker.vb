﻿Imports System.Drawing
Imports System.Windows.Forms

Public Class ShowColourPicker

    Public Shared Function GetRGBColour() As Integer
        Dim RValue, GValue, BValue, RGBValue As Integer

        Dim dlgColourPicker As New ColorDialog()

        dlgColourPicker.AllowFullOpen = False

        If dlgColourPicker.ShowDialog() = DialogResult.OK Then
            RValue = dlgColourPicker.Color.R
            GValue = dlgColourPicker.Color.G
            BValue = dlgColourPicker.Color.B
            RGBValue = 65536 * RValue + 256 * GValue + BValue
            GetRGBColour = RGBValue
        Else
            GetRGBColour = 999
        End If
    End Function

End Class
