﻿Imports System.Windows.Forms
Imports System.IO

Public Class dlgConditions

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub dlgConditions_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        On Error Resume Next

        Dim TitlefilePath As String = "L:\TL_GIS\DATA\BASE_DATA\Apps\MBXs\Resources\ConditionsTitle.txt"
        Dim TitlefileContents As String = File.ReadAllText(TitlefilePath)

        Dim HeaderfilePath As String = "L:\TL_GIS\DATA\BASE_DATA\Apps\MBXs\Resources\ConditionsHeader.txt"
        Dim HeaderfileContents As String = File.ReadAllText(HeaderfilePath)

        Dim Body1filePath As String = "L:\TL_GIS\DATA\BASE_DATA\Apps\MBXs\Resources\ConditionsBody1.txt"
        Dim Body1fileContents As String = File.ReadAllText(Body1filePath)

        lblTitle.Text = TitlefileContents
        lblHeader.Text = HeaderfileContents
        lblBody1.Text = Body1fileContents

    End Sub

    Private Sub cbxAccept_CheckedChanged(sender As Object, e As EventArgs) Handles cbxAccept.CheckedChanged
        OK_Button.Enabled = True
    End Sub
End Class
