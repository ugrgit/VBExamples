﻿
Public Class ShowConditionsForm
    Public Shared Function ShowConditionsDialog() As Integer
        Dim dlgConditionsForm As New dlgConditions

        Dim result = dlgConditionsForm.ShowDialog

        If result = Windows.Forms.DialogResult.OK Then
            ShowConditionsDialog = 1
        Else
            ShowConditionsDialog = 999
        End If

    End Function
End Class