﻿Imports System.Windows.Forms

Public Class dlgGetInfo
    Public ProgressBar1 As ProgressBar
    Dim Label1 As Label

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        SelectDialog.gInfo = ComboBox1.Text
        If Len(ComboBox2.Text) > 0 Then
            SelectDialog.gInfo = SelectDialog.gInfo & ", " & ComboBox2.Text
        End If
        If Len(ComboBox3.Text) > 0 Then
            SelectDialog.gInfo = SelectDialog.gInfo & ", " & ComboBox3.Text
        End If
        If Len(ComboBox4.Text) > 0 Then
            SelectDialog.gInfo = SelectDialog.gInfo & ", " & ComboBox4.Text
        End If
        If Len(ComboBox5.Text) > 0 Then
            SelectDialog.gInfo = SelectDialog.gInfo & ", " & ComboBox5.Text
        End If
        Me.Close()
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        SelectDialog.gInfo = ""
        Me.Close()
    End Sub
    Private Sub dlgGetInfo_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If Not IO.File.Exists(SelectDialog.gFilePath) Then
            MsgBox("Cannot find the file for the list values. Cannot continue")
            Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
            Me.Close()
        End If
        Me.Text = SelectDialog.gTitle
    End Sub
    Private Sub PopulateComboxBox(FilePath As String, ComboBox As Object, Increment As Integer)
        ProgressBar1.Value = ProgressBar1.Value + Increment
        ProgressBar1.Refresh()
        Using sr As New IO.StreamReader(FilePath)
            While Not sr.EndOfStream
                ComboBox.Items.Add(sr.ReadLine)
            End While
        End Using
        ProgressBar1.Value = ProgressBar1.Value + Increment
        ProgressBar1.Refresh()
    End Sub

    Private Sub dlgGetInfo_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown
        ProgressBar1 = New ProgressBar()
        Label1 = New Label
        'set position
        Label1.Text = "Loading values, please wait..."
        Label1.Location = New Drawing.Point(10, 10)
        Label1.Width = 300
        Me.Controls.Add(Label1)
        Label1.Refresh()
        'MsgBox("text should be displayed")
        ProgressBar1.Location = New Drawing.Point(10, 30)
        ProgressBar1.Width = 300
        'set values
        ProgressBar1.Minimum = 0
        ProgressBar1.Maximum = 100
        ProgressBar1.Value = 0
        'add the progress bar to the form
        Me.Controls.Add(ProgressBar1)
        Select Case SelectDialog.gNumberComboBoxes
            Case 1
                PopulateComboxBox(SelectDialog.gFilePath, ComboBox1, 50)
                ProgressBar1.Value = 100
                ComboBox1.Visible = True
                Me.Controls.Remove(Label1)
                Me.Controls.Remove(ProgressBar1)
            Case 2
                PopulateComboxBox(SelectDialog.gFilePath, ComboBox1, 20)
                PopulateComboxBox(SelectDialog.gFilePath, ComboBox2, 20)
                ComboBox1.Visible = True
                ComboBox2.Visible = True
                Me.Controls.Remove(Label1)
                Me.Controls.Remove(ProgressBar1)
            Case 3
                PopulateComboxBox(SelectDialog.gFilePath, ComboBox1, 15)
                PopulateComboxBox(SelectDialog.gFilePath, ComboBox2, 15)
                PopulateComboxBox(SelectDialog.gFilePath, ComboBox3, 15)
                ComboBox1.Visible = True
                ComboBox2.Visible = True
                ComboBox3.Visible = True
                Me.Controls.Remove(Label1)
                Me.Controls.Remove(ProgressBar1)
            Case 4
                PopulateComboxBox(SelectDialog.gFilePath, ComboBox1, 10)
                PopulateComboxBox(SelectDialog.gFilePath, ComboBox2, 10)
                PopulateComboxBox(SelectDialog.gFilePath, ComboBox3, 10)
                PopulateComboxBox(SelectDialog.gFilePath, ComboBox4, 10)
                ComboBox1.Visible = True
                ComboBox2.Visible = True
                ComboBox3.Visible = True
                ComboBox4.Visible = True
                Me.Controls.Remove(Label1)
                Me.Controls.Remove(ProgressBar1)
            Case 5
                PopulateComboxBox(SelectDialog.gFilePath, ComboBox1, 7)
                PopulateComboxBox(SelectDialog.gFilePath, ComboBox2, 7)
                PopulateComboxBox(SelectDialog.gFilePath, ComboBox3, 7)
                PopulateComboxBox(SelectDialog.gFilePath, ComboBox4, 7)
                PopulateComboxBox(SelectDialog.gFilePath, ComboBox5, 7)
                ComboBox1.Visible = True
                ComboBox2.Visible = True
                ComboBox3.Visible = True
                ComboBox4.Visible = True
                ComboBox5.Visible = True
                Me.Controls.Remove(Label1)
                Me.Controls.Remove(ProgressBar1)
        End Select

    End Sub

    Private Sub ComboBox1_SelectionChangeCommitted(sender As Object, e As EventArgs) Handles ComboBox1.SelectionChangeCommitted
        ComboBox2.Enabled = True
    End Sub

    Private Sub ComboBox2_SelectionChangeCommitted(sender As Object, e As EventArgs) Handles ComboBox2.SelectionChangeCommitted
        ComboBox3.Enabled = True
    End Sub

    Private Sub ComboBox3_SelectionChangeCommitted(sender As Object, e As EventArgs) Handles ComboBox3.SelectionChangeCommitted
        ComboBox4.Enabled = True
    End Sub

    Private Sub ComboBox4_SelectionChangeCommitted(sender As Object, e As EventArgs) Handles ComboBox4.SelectionChangeCommitted
        ComboBox5.Enabled = True
    End Sub
End Class
