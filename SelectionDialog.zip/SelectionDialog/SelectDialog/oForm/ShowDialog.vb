﻿Namespace oForm
    Friend Class ShowDialog
    End Class
End Namespace
