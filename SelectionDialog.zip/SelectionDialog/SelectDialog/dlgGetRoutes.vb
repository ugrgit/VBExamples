﻿Imports System.Windows.Forms

Public Class dlgGetRoutes
    Private Const V As String = "L:\TL_GIS\DATA\BASE_DATA\STIMS\STIMSStudentRoutes.txt"

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub dlgGetRoutes_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            If IO.File.Exists(V) Then
                Using sr As New IO.StreamReader(V)
                    While Not sr.EndOfStream
                        ComboBox1.Items.Add(sr.ReadLine)
                        ComboBox2.Items.Add(sr.ReadLine)
                        ComboBox3.Items.Add(sr.ReadLine)
                        ComboBox4.Items.Add(sr.ReadLine)
                        ComboBox5.Items.Add(sr.ReadLine)
                    End While
                End Using
            Else
                MsgBox("Oooops, File not found !!!")
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
End Class
