﻿Public Class SelectDialog
    Public Shared Property gFilePath As String
    Public Shared Property gNumberComboBoxes As Integer
    Public Shared Property gTitle As String
    Public Shared Property gInfo As String

    Public Shared Function OpenDialog(NumberComboBoxes As Integer, FilePath As String, Title As String) As String
        Dim oForm As New dlgGetInfo

        gFilePath = FilePath
        gNumberComboBoxes = NumberComboBoxes
        If gNumberComboBoxes > 5 Then
            gNumberComboBoxes = 5
        End If
        gTitle = Title

        oForm.ShowDialog()

        OpenDialog = gInfo

    End Function

    Public Shared Sub OpenRouteDialog(FilePath As String)
        Dim oForm As New dlgGetRoutes

        oForm.ShowDialog()

    End Sub
End Class
